# NexusPointWG

一个现代化的 WireGuard VPN 管理平台，提供直观的 Web 界面，让 VPN 服务器的配置和管理变得简单高效。

## 项目简介

NexusPointWG 是一个功能完整的 WireGuard 管理平台，通过 Web 界面帮助您轻松管理 VPN 服务器。无需手动编辑配置文件，无需记忆复杂的命令，只需在浏览器中点击几下，就能完成用户管理、设备配置、IP 分配等所有操作。

## 核心功能

### 🔐 用户与权限管理

**功能说明**：支持多用户管理，不同用户拥有不同的权限范围。

- **管理员角色**：可以管理所有用户和设备，配置 IP 地址池
- **普通用户角色**：只能管理自己的设备配置
- **安全登录**：使用 Token 认证，保障系统安全

**使用场景**：适合团队使用，管理员统一管理，普通用户自助管理自己的设备。

### 🌐 设备（Peer）管理

**功能说明**：完整的设备生命周期管理，从创建到删除，全程自动化。

- **一键创建设备**：自动生成密钥对，自动分配 IP 地址，无需手动操作
- **灵活配置**：支持自定义设备名称、允许的 IP 段、DNS 服务器等
- **配置下载**：一键下载客户端配置文件，直接导入 WireGuard 客户端使用
- **启用/禁用**：随时启用或禁用设备，无需删除配置
- **自动同步**：所有操作自动同步到 WireGuard 服务器配置

**使用场景**：
- 为新员工快速创建 VPN 连接
- 临时禁用某个设备的访问权限
- 修改设备的网络配置（如 DNS、允许的 IP 段）

### 📊 IP 地址池管理

**功能说明**：智能管理 IP 地址分配，避免冲突，提高利用率。

- **多 IP 池支持**：可以创建多个 IP 地址池，灵活分配
- **自动分配**：系统自动从可用 IP 中分配，无需手动选择
- **使用情况查询**：随时查看哪些 IP 已使用，哪些可用
- **自动回收**：删除设备时自动释放 IP 地址，可重复使用

**使用场景**：
- 为不同部门分配不同的 IP 段
- 查看 IP 地址使用情况，规划扩容
- 避免手动分配导致的 IP 冲突

### ⚙️ 服务器配置自动管理

**功能说明**：自动管理 WireGuard 服务器配置文件，无需手动编辑。

- **自动读取**：自动读取现有 WireGuard 配置
- **自动更新**：创建、修改、删除设备时自动更新服务器配置
- **自动应用**：支持自动重载配置（可选），立即生效
- **配置备份**：更新前自动备份，确保安全

**使用场景**：
- 避免手动编辑配置文件出错
- 配置变更立即生效，无需重启服务
- 配置错误时可快速恢复

### 🎨 现代化 Web 界面

**功能说明**：直观易用的 Web 界面，随时随地管理 VPN。

- **响应式设计**：支持电脑、平板、手机访问
- **实时更新**：操作结果实时反馈
- **操作简单**：所有功能通过点击完成，无需命令行

## 快速开始

### 前置要求

- 已安装并运行 WireGuard 服务器
- WireGuard 配置文件位于 `/etc/wireguard/wg0.conf`（或自定义路径）
- Docker 和 Docker Compose（推荐使用 Docker 部署）

> **开发者注意**：如果您需要从源码构建和运行，请参考 [开发指南](docs/dev.md)。

### Docker 部署（推荐）

#### 1. 拉取镜像

从 Docker Hub 拉取最新版本：

```bash
docker pull happlelaoganma/nexuspointwg:latest
```

或者拉取指定版本：

```bash
docker pull happlelaoganma/nexuspointwg:1.0.1
```

#### 2. 配置 WireGuard 服务器

确保您的 WireGuard 服务器已正确配置。默认配置文件路径为 `/etc/wireguard/wg0.conf`。

#### 3. 设置目录权限

容器内运行用户为 `NexusPointWG`，UID 为 `51830`。需要确保宿主机 `/etc/wireguard` 目录对容器用户可写（用于生成/更新配置与数据库）：

```bash
sudo chown -R 51830:51830 /etc/wireguard
sudo chmod 755 /etc/wireguard
```

> **注意**：请根据实际运维需要自行权衡是否直接修改 `/etc/wireguard` 的属主/权限，或改用单独的数据目录。

#### 4. 运行容器

**方式一：使用 Docker Compose（推荐）**

首先需要修改项目中的 `docker-compose.release.yml`，将镜像名称改为 `happlelaoganma/nexuspointwg:${IMAGE_TAG:-latest}`，然后运行：

```bash
# 设置环境变量 IMAGE_TAG（例如：1.0.1 或 latest）
IMAGE_TAG=latest docker compose -f docker-compose.release.yml up -d
```

**方式二：直接使用 Docker 命令（无需修改配置文件）**

```bash
docker run -d \
  --name nexuspointwg \
  --privileged \
  --pid host \
  -p 51830:51830 \
  -v /etc/wireguard:/etc/wireguard:rw \
  --restart unless-stopped \
  happlelaoganma/nexuspointwg:latest \
  -c /app/configs/NexusPointWG.yaml \
  --wireguard.endpoint=your-server-ip:51820 \
  --jwt.secret=your-secret-key
```

**必需参数说明**：
- `--wireguard.endpoint`：您的服务器公网 IP 和端口（如：`123.45.67.89:51820`）
- `--jwt.secret`：JWT 密钥，用于 Token 加密（建议使用随机字符串）

#### 5. 访问 Web 界面

启动成功后，在浏览器中访问：

- **Web 界面**：http://your-server-ip:51830
- **API 文档**：http://your-server-ip:51830/swagger/index.html

## 使用指南

### 首次使用

#### 1. 注册管理员账号

首次使用时，访问注册页面创建管理员账号。第一个注册的用户将自动获得管理员权限。

#### 2. 创建 IP 地址池

登录后，进入 IP 池管理页面，创建您的第一个 IP 地址池：

- **IP 池地址**：输入 CIDR 格式的 IP 段，如 `10.0.0.0/24`
- **描述**：可选，用于说明这个 IP 池的用途

**示例**：
- 如果您的 WireGuard 服务器 IP 是 `10.0.0.1`，可以创建 IP 池 `10.0.0.0/24`
- 系统会自动跳过服务器 IP（10.0.0.1），从其他可用 IP 中分配

#### 3. 创建第一个设备（Peer）

进入设备管理页面，点击"创建设备"：

- **设备名称**：输入一个便于识别的名称，如"张三的笔记本"
- **IP 地址**：可以选择"自动分配"或手动指定
- **AllowedIPs**：允许该设备访问的 IP 段，默认 `0.0.0.0/0`（所有流量）
- **DNS**：DNS 服务器地址，可选
- **启用状态**：选择是否立即启用

创建成功后，点击"下载配置"按钮，将配置文件导入到 WireGuard 客户端即可使用。

### 日常使用场景

#### 场景一：为新员工创建 VPN 连接

1. 登录管理界面
2. 进入"设备管理"页面
3. 点击"创建设备"
4. 填写设备名称（如"李四的手机"）
5. 选择 IP 地址为"自动分配"
6. 保持其他默认设置
7. 点击"创建"
8. 下载配置文件，发送给新员工
9. 新员工在 WireGuard 客户端导入配置即可使用

#### 场景二：临时禁用某个设备

1. 进入"设备管理"页面
2. 找到需要禁用的设备
3. 点击"禁用"按钮
4. 设备立即无法连接 VPN
5. 需要时点击"启用"即可恢复

#### 场景三：修改设备的网络配置

1. 进入"设备管理"页面
2. 找到需要修改的设备
3. 点击"编辑"按钮
4. 修改 DNS、AllowedIPs 等配置
5. 保存后配置自动同步到服务器

#### 场景四：查看 IP 地址使用情况

1. 进入"IP 池管理"页面
2. 点击某个 IP 池的"查看可用 IP"
3. 查看哪些 IP 已分配，哪些可用
4. 根据使用情况决定是否需要扩容

### 配置说明

#### WireGuard 相关配置

| 参数 | 说明 | 默认值 | 是否必需 |
|------|------|--------|----------|
| `--wireguard.root-dir` | WireGuard 配置目录 | `/etc/wireguard` | 否 |
| `--wireguard.interface` | 服务器接口名称 | `wg0` | 否 |
| `--wireguard.endpoint` | 服务器公网端点（IP:端口） | - | **是** |
| `--wireguard.dns` | 默认 DNS 服务器 | - | 否 |
| `--wireguard.default-allowed-ips` | 默认 AllowedIPs | `0.0.0.0/0` | 否 |
| `--wireguard.apply-method` | 配置应用方式 | `none` | 否 |

**配置应用方式说明**：
- `systemctl`：自动执行 `systemctl reload wg-quick@wg0` 使配置立即生效
- `none`：仅更新配置文件，需要手动重载

#### 其他配置

| 参数 | 说明 | 默认值 | 是否必需 |
|------|------|--------|----------|
| `--sqlite.database` | 数据库文件路径 | `NexusPointWG.db` | 否 |
| `--jwt.secret` | JWT 密钥 | - | **是** |
| `--jwt.timeout` | Token 过期时间 | `24h` | 否 |

## 功能详解

### 自动 IP 分配机制

系统在分配 IP 地址时会自动：
- 跳过网络地址（如 `10.0.0.0`）
- 跳过广播地址（如 `10.0.0.255`）
- 跳过服务器 IP 地址
- 优先分配未使用过的 IP
- 支持手动指定 IP（需确保不冲突）

### 配置文件同步机制

- **创建设备时**：自动在服务器配置文件中添加 Peer 配置
- **更新设备时**：自动更新服务器配置文件中对应的 Peer 配置
- **删除设备时**：自动从服务器配置文件中移除 Peer 配置
- **配置备份**：每次更新前自动备份，备份文件保存在配置目录下

### 客户端配置生成

下载的配置文件包含：
- 客户端私钥（自动生成）
- 服务器公钥（从服务器配置读取）
- 服务器端点（Endpoint）
- 分配的 IP 地址
- DNS 服务器（如果配置）
- AllowedIPs（允许的 IP 段）

配置文件可直接导入 WireGuard 客户端使用，无需手动修改。

## 权限说明

### 角色权限

**管理员（admin）**
- 可以管理所有用户和设备
- 可以创建和管理 IP 地址池
- 可以查看所有设备的配置和状态

**普通用户（user）**
- 只能管理自己创建的设备
- 可以查看自己的设备列表和配置
- 可以下载自己设备的配置文件
- 无法管理 IP 地址池和其他用户的设备

### 权限控制

系统采用基于角色的访问控制（RBAC），确保：
- 用户只能访问和操作自己的资源
- 管理员拥有完整的管理权限
- 所有操作都有权限验证，保障系统安全

## 常见问题

### Q: 如何修改 WireGuard 配置路径？

A: 使用 `--wireguard.root-dir` 参数指定配置目录，例如：
```bash
./bin/NexusPointWG --wireguard.root-dir=/custom/path/wireguard
```

### Q: 配置文件更新后如何生效？

A: 有两种方式：
1. **自动生效**：设置 `--wireguard.apply-method=systemctl`，系统会自动重载配置
2. **手动生效**：使用默认设置，然后手动执行 `sudo systemctl reload wg-quick@wg0`

### Q: 配置文件更新失败怎么办？

A: 系统会在更新前自动备份配置文件，备份文件位于配置目录下。如果更新失败：
1. 查看日志了解失败原因
2. 使用备份文件恢复配置
3. 检查文件权限和磁盘空间

### Q: 如何查看系统日志？

A: 日志默认输出到标准输出，可以通过重定向保存到文件：
```bash
./bin/NexusPointWG > nexuspointwg.log 2>&1
```

### Q: 支持 Docker 部署吗？

A: 支持！推荐使用 Docker 部署，详细说明见上方"快速开始"章节。如需从源码构建或开发调试，请参考 [开发指南](docs/dev.md)。

### Q: 如何备份数据？

A: 系统使用 SQLite 数据库，只需备份数据库文件即可。数据库文件路径由 `--sqlite.database` 或配置文件中的 `sqlite.data-source-name` 指定。


## API 接口

系统提供完整的 RESTful API，支持通过 API 进行所有操作。详细的 API 文档请访问：

**Swagger UI**：http://your-server-ip:51830/swagger/index.html

主要 API 接口包括：
- 用户注册和登录
- 设备（Peer）的创建、查询、更新、删除
- IP 池的创建和管理
- 配置文件的下载

## 相关文档

- [开发指南](docs/dev.md) - 开发环境搭建、源码构建、开发调试指南
- [项目分层规范](docs/项目分层规范.md) - 开发者架构设计文档
- [API 接口规范](docs/api-contract.md) - API 接口对接规范
- [UI 设计规范](docs/design/UI_SPECS.md) - 前端 UI 设计指南

## 贡献指南

欢迎提交 Issue 和 Pull Request！

1. Fork 本仓库
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启 Pull Request

## 许可证

本项目采用 MIT 许可证。

## 联系方式

如有问题或建议，请通过以下方式联系：

- 提交 Issue: [GitHub Issues](https://github.com/HappyLadySauce/NexusPointWG/issues)
- 项目地址: [GitHub Repository](https://github.com/HappyLadySauce/NexusPointWG)

---

**NexusPointWG** - 让 WireGuard 管理更简单 🚀
