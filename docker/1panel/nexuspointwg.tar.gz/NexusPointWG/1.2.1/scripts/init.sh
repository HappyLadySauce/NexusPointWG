chown -R 51830:51830 /etc/wireguard
chmod 755 /etc/wireguard